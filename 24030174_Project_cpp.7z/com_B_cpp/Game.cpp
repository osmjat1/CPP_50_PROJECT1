#include<iostream>
#include<conio.h>
#include<algorithm>
#include<windows.h>
#include<vector>
#include<fstream>
#include<string>
#include<ctime>
#define cls system("cls")
#define red FOREGROUND_RED
#define blue FOREGROUND_BLUE
#define green FOREGROUND_GREEN
#define yellow (FOREGROUND_RED | FOREGROUND_GREEN)
#define color SetConsoleTextAttribute
using namespace std;

HANDLE han = GetStdHandle(STD_OUTPUT_HANDLE); // Gets handle to the console output
COORD cor;

// define class
class GameBase {
protected:
    struct Level {
        vector<vector<string>> map; // 2D vector for level map
        int startX, startY;
        int endX, endY;
    };

    vector<Level> levels; // List of all levels
    int currentLevel = 0;
    int score = 0;

public:
    virtual ~GameBase() = default;  // Virtual destructor

    virtual void showInstructions() {  // Displays basic instructions
        cls;
        color(han, yellow);
        cout << "=== GAME INSTRUCTIONS ===" << endl;
        color(han, green);
        cout << "O - Player" << endl;
        cout << "W - Move up" << endl;
        cout << "S - Move down" << endl;
        cout << "A - Move left" << endl;
        cout << "D - Move right" << endl;
        color(han, yellow);
        cout << "\nPress V to quit the game" << endl;
        cout << "Press any key to continue..." << endl;
        _getch();
    }

    void setCursorPosition(int x, int y) {
        cor.X = y;
        cor.Y = x;
        SetConsoleCursorPosition(han, cor);  // Move cursor
    }

    void printMap(const vector<vector<string>>& map, bool initialPrint = false) {
        if (initialPrint) {
            cls;
            for (size_t x = 0; x < map.size(); ++x) {
                for (size_t y = 0; y < map[x].size(); y++) {
                    if (map[x][y] == "O") {
                        color(han, green);
                    }
                    else if (map[x][y] == "#") {
                        color(han, blue);
                    }
                    else if (map[x][y] == "X") {
                        color(han, red);
                    }
                    else {
                        color(han, FOREGROUND_INTENSITY);
                    }
                    cout << map[x][y];
                }
                cout << endl;
            }
        }
        else {
            for (size_t x = 0; x < map.size(); ++x) {
                for (size_t y = 0; y < map[x].size(); y++) {
                    if (map[x][y] == "O" || map[x][y] == " " || map[x][y] == "X") {
                        setCursorPosition(x, y);
                        if (map[x][y] == "O") {
                            color(han, green);
                        }
                        else if (map[x][y] == "X") {
                            color(han, red);
                        }
                        else {
                            color(han, FOREGROUND_INTENSITY);
                        }
                        cout << map[x][y];
                    }
                }
            }
        }

        setCursorPosition(map.size() + 1, 0);
        color(han, yellow);
        cout << "Level: " << currentLevel + 1 << "/" << levels.size() << "  Score: " << score << "   ";
    }

    virtual void initLevels() = 0;
    virtual bool playLevel(Level& level) = 0;
};

// Intermediate class for games with score saving capability
class ScoredGame : public GameBase {
protected:
    string scoreFile = "README.md";
    string playerName;

    struct ScoreEntry {
        char name[50];
        int level;
        int score;
        char date[26];
    };

    void getPlayerName() {
        cls;
        color(han, yellow);
        cout << "Enter your name: ";
        getline(cin, playerName);  // Read full line input for name
        if (playerName.empty()) {
            playerName = "Anonymous";
        }
    }

    void saveScore() {
        ofstream outFile(scoreFile, ios::app | ios::binary); //Open the score file in append mode and binary mode
        if (outFile.is_open()) {
            ScoreEntry entry;
            strncpy_s(entry.name, playerName.c_str(), 49);
            entry.level = currentLevel + 1;
            entry.score = score;

            time_t now = time(0);
            ctime_s(entry.date, sizeof(entry.date), &now);

            outFile.write(reinterpret_cast<char*>(&entry), sizeof(ScoreEntry)); //Write the entire ScoreEntry structure to the file in binary format
            outFile.close();
        }
    }

    void showHighScores() {
        ifstream inFile(scoreFile, ios::binary); //Open the score file in binary input
        if (inFile.is_open()) {
            vector<ScoreEntry> scores;
            ScoreEntry entry;
            // Loop through the file, reading binary ScoreEntry objects and adding them to the scores vector.
            while (inFile.read(reinterpret_cast<char*>(&entry), sizeof(ScoreEntry))) {
                scores.push_back(entry);
            }

            //Sort the vector so that the highest scores come first, using a lambda function to compare entries.
            sort(scores.begin(), scores.end(), [](const ScoreEntry& a, const ScoreEntry& b) {
                return a.score > b.score;
            });

            cls;
            color(han, yellow);
            cout << "=== HIGH SCORES ===\n" << endl;
            cout << "Player\t\tLevel\tScore\t\tDate" << endl;
            cout << "----------------------------------------------" << endl;

            int count = min(10, (int)scores.size());
            for (int i = 0; i < count; i++) {
                cout << scores[i].name << "\t\t" << scores[i].level << "\t"
                     << scores[i].score << "\t\t" << scores[i].date;
            }

            cout << "\nPress any key to continue..." << endl;
            _getch();
        }
    }

public:
    virtual void showInstructions() override {
        GameBase::showInstructions(); //Call the base class version first to show default instructions
        color(han, yellow);
        cout << "Press H to view high scores" << endl;
    }
};

// MazeGame implementation
class MazeGame : public ScoredGame {
public:
    void initLevels() override {
        // Level 1 Push a new Level structure to the levels vector
        levels.push_back({
            {
                {"#","#","#","#","#","#","#","#","#","#","#","#","#","#","#","#","#","#","#","#","#","#","#","#","#","#","#","#","#","#"},
                {"#"," "," "," "," "," ","#"," "," "," "," ","#"," ","#"," "," "," "," "," "," ","#"," "," "," "," "," "," "," "," ","X"},
                {"#"," "," ","#"," "," "," "," "," ","#"," "," "," ","#"," "," ","#"," "," "," "," "," "," "," ","#","#","#","#","#","#"},
                {"#","#","#","#","#","#","#","#"," ","#","#","#"," ","#"," "," ","#"," "," ","#"," "," "," "," ","#","#"," "," "," ","#"},
                {"#"," "," "," "," "," ","#"," "," "," "," ","#"," ","#"," "," ","#","#"," ","#"," ","#","#"," ","#"," "," ","#"," ","#"},
                {"#"," ","#","#","#"," ","#"," ","#"," "," ","#"," ","#"," "," "," "," "," "," "," ","#"," "," "," "," ","#","#"," ","#"},
                {"#"," ","#"," "," "," ","#","#","#"," "," ","#","#","#"," "," ","#","#","#","#","#","#"," ","#"," "," ","#"," "," ","#"},
                {"#"," ","#","#"," "," "," "," "," "," "," "," "," ","#"," ","#","#"," "," "," "," ","#"," "," ","#"," ","#"," ","#","#"},
                {"#"," "," ","#","#","#","#","#","#","#","#"," "," "," "," "," ","#"," "," ","#"," "," "," "," "," "," ","#"," "," ","#"},
                {"#"," "," "," "," ","#"," "," "," "," "," "," "," ","#","#"," ","#","#","#","#","#","#","#"," "," "," ","#","#","#","#"},
                {"#"," ","#","#"," ","#","#"," "," ","#","#","#"," ","#"," "," "," "," "," "," "," ","#"," "," "," ","#","#"," "," ","#"},
                {"#"," ","#"," "," ","#"," "," "," "," "," ","#"," ","#","#"," ","#","#","#"," "," "," "," "," "," "," "," "," "," ","#"},
                {"#"," ","#"," ","#"," "," "," ","#"," "," ","#"," "," "," "," ","#"," ","#","#"," ","#"," "," ","#"," "," ","#","#","#"},
                {"#"," ","#"," "," "," ","#"," ","#","#"," ","#","#","#","#","#","#"," "," "," "," ","#"," "," ","#"," "," "," "," ","#"},
                {"#","#","#"," ","#","#","#","#"," "," "," ","#"," ","#","#","#","#","#","#"," "," "," "," "," "," "," ","#","#","#","#"},
                {"#"," "," "," "," "," "," ","#","#"," ","#","#"," "," "," "," "," "," "," ","#","#","#","#","#"," "," "," "," "," ","#"},
                {"#"," "," "," ","#","#"," "," ","#"," "," "," "," ","#","#","#","#"," "," "," "," "," "," ","#","#","#"," "," "," ","#"},
                {"#"," ","#"," "," ","#","#"," ","#","#","#","#","#","#"," "," ","#"," ","#","#","#","#"," "," "," "," "," "," ","#","#"},
                {"#","O","#"," "," "," "," "," "," "," "," "," "," "," "," "," ","#"," ","#"," "," "," "," ","#"," "," "," "," "," ","#"},
                {"#","#","#","#","#","#","#","#","#","#","#","#","#","#","#","#","#","#","#","#","#","#","#","#","#","#","#","#","#","#"}
            },
            18, 1, 1, 29
        });

        // Level 2
        levels.push_back({
            {
                {"#","#","#","#","#","#","#","#","#","#","#","#","#","#","#","#","#","#","#","#","#","#","#","#","#","#","#","#","#","#"},
                {"#","X"," "," "," "," ","#"," "," "," "," ","#"," ","#"," "," "," "," "," "," ","#"," "," "," "," "," "," "," "," ","#"},
                {"#","#","#","#","#"," ","#"," ","#","#"," ","#"," ","#"," ","#","#","#","#"," ","#"," ","#","#","#","#","#","#"," ","#"},
                {"#"," "," "," ","#"," "," "," ","#"," "," ","#"," "," "," ","#"," "," ","#"," "," "," ","#"," "," "," "," ","#"," ","#"},
                {"#"," ","#"," ","#","#","#","#","#"," ","#","#","#","#"," ","#"," "," ","#","#","#"," ","#"," ","#"," ","#"," ","#"},
                {"#"," ","#"," "," "," "," "," "," "," "," "," "," "," "," ","#","#"," "," "," "," "," ","#"," ","#"," ","#"," ","#"},
                {"#"," ","#","#"," ","#","#","#","#","#","#","#"," ","#"," "," ","#","#","#","#","#","#"," ","#"," ","#"," ","#"},
                {"#"," "," "," "," "," "," "," "," "," "," "," "," ","#","#"," "," "," "," "," "," "," "," ","#"," ","#"," ","#"},
                {"#","#","#","#","#","#","#","#","#","#"," ","#"," "," ","#","#","#","#","#","#","#","#","#"," ","#"," ","#"},
                {"#"," "," "," "," "," "," "," "," ","#"," ","#","#"," "," "," "," "," "," "," "," "," "," "," ","#"," ","#"},
                {"#"," ","#","#","#","#","#","#"," ","#"," "," ","#","#","#","#","#","#","#","#","#","#","#","#"," ","#"},
                {"#"," ","#"," "," "," "," ","#"," ","#","#"," "," "," "," "," "," "," "," "," "," "," "," "," "," ","#"},
                {"#"," ","#"," ","#","#"," ","#"," "," ","#","#","#","#","#","#","#","#","#","#","#","#","#"," ","#"},
                {"#"," ","#"," ","#"," "," ","#","#"," "," "," "," "," "," "," "," "," "," "," "," "," "," "," ","#"},
                {"#"," ","#"," ","#","#","#"," ","#","#","#","#","#","#","#","#","#","#","#","#","#","#"," "," ","#"},
                {"#"," ","#"," "," "," "," "," "," "," "," "," "," "," "," "," "," "," "," "," "," ","#"," "," ","#"},
                {"#"," ","#","#","#","#","#","#","#","#","#","#","#","#","#","#","#","#","#","#"," ","#"," "," ","#"},
                {"#"," "," "," "," "," "," "," "," "," "," "," "," "," "," "," "," "," "," ","#"," ","#"," "," ","#"},
                {"#","O","#","#","#","#","#","#","#","#","#","#","#","#","#","#","#","#"," "," "," "," "," "," ","#"},
                {"#","#","#","#","#","#","#","#","#","#","#","#","#","#","#","#","#","#","#","#","#","#","#","#","#"}
            },
            18, 1, 1, 1
        });
    }

    bool playLevel(Level& level) override {
        vector<vector<string>> map = level.map;  // Copy the level map into a local map
        int x = level.startX;
        int y = level.startY;
        bool quit = false;
        bool completed = false;

        CONSOLE_CURSOR_INFO cursorInfo;
        GetConsoleCursorInfo(han, &cursorInfo);
        cursorInfo.bVisible = false;    // Hide the blinking console cursor
        SetConsoleCursorInfo(han, &cursorInfo);

        printMap(map, true);
        // Game loop until level is completed or quit
        while (!completed && !quit) {
            map[x][y] = "O";
            printMap(map);
            // Tracks whether player has moved
            bool moved = false;
            while (!moved) {
                if (_kbhit()) {
                    char key = _getch();
                    int newX = x, newY = y;
                    // Handle key input
                    switch (tolower(key)) {
                        case 'w': newX--; break;
                        case 's': newX++; break;
                        case 'a': newY--; break;
                        case 'd': newY++; break;
                        case 'v': quit = true; moved = true; break;
                        case 'h': showHighScores(); printMap(map, true); break;
                        default: break;
                    }
                    // If not quitting and not hitting wall
                    if (!quit && map[newX][newY] != "#") {
                        setCursorPosition(x, y);
                        color(han, FOREGROUND_INTENSITY);
                        cout << " ";

                        map[x][y] = " ";
                        x = newX;
                        y = newY;

                        setCursorPosition(x, y);
                        color(han, green);
                        cout << "O";

                        moved = true;
                        score++;

                        if (x == level.endX && y == level.endY) {
                            completed = true;
                            saveScore();
                        }

                        setCursorPosition(map.size() + 1, 0);
                        color(han, yellow);
                        cout << "Level: " << currentLevel + 1 << "/" << levels.size() << "  Score: " << score << "   ";
                    }
                }
            }
        }

        cursorInfo.bVisible = true;
        SetConsoleCursorInfo(han, &cursorInfo);

        if (completed) {
            cls;
            color(han, green);
            cout << "LEVEL COMPLETED!" << endl;
            cout << "Score: " << score << endl;
            color(han, yellow);
            cout << "\nPress any key to continue..." << endl;
            _getch();
        }
        return completed;
    }

    void startGame() {
        SMALL_RECT windowSize = { 0, 0, 29, 22 };
        SetConsoleWindowInfo(han, TRUE, &windowSize);  // Resize the console window

        getPlayerName();
        initLevels();
        showInstructions();

        for (currentLevel = 0; currentLevel < levels.size(); currentLevel++) {
            bool success = playLevel(levels[currentLevel]);
            if (!success) break;

            score += 100 * (levels.size() - currentLevel);
        }

        cls;
        if (currentLevel == levels.size()) {
            color(han, green);
            cout << "CONGRATULATIONS " << playerName << "! YOU COMPLETED ALL LEVELS!" << endl;
        } else {
            color(han, red);
            cout << "GAME OVER" << endl;
        }
        color(han, yellow);
        cout << "Final Score: " << score << endl;
        saveScore();
        cout << "\nPress any key to view high scores..." << endl;
        _getch();

        showHighScores();
    }
};

int main() {
    MazeGame game;
    game.startGame();
    return 0;
}

